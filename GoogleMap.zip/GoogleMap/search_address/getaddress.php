<?php
$address = $_POST["value"];
$key = "AIzaSyAmLYjKTYOe8NVNKJ42mnFOO2iEoQck_W4";
$url = "https://maps.googleapis.com/maps/api/geocode/json?address={$address}&key=$key";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);    
$body = curl_exec($ch);
echo $body;
curl_close($ch);  
?>