<!DOCTYPE html>
<html>
  <head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <style>
       /* Set the size of the div element that contains the map */
      #map {
        height: 400px;  /* The height is 400 pixels */
        width: 100%;  /* The width is the width of the web page */
       }
    </style>
  </head>
  <body>
    <h3>My Google Maps Demo</h3>
    <form method="post" action="#" name="search_form" id="search_form">
      <input type="text" name="search" id="search" placeholder="search zipcode" />
      <input type="submit" name="submit" id="submit" value="search" />
    </form>
    <!--The div element for the map -->
    <div id="map"></div>
    <script>
      $( "#search_form" ).submit(function( event ) {
        var value = $("#search").val();
        event.preventDefault();
        $.ajax({
            url: "getaddress.php",
            type: "post",
            data: { value : value },
            dataType: "json",
            success: function(data) {
              initMap(data["PakkeshopData"]);
              //console.log(data["PakkeshopData"]);
            }
        });
      });
      $(document).ready(function(){
          var lat = '-25.344';
          var lng = '131.036';
          var address = [];
          initMap(address);
      });
      // Initialize and add the map
      function initMap(array) {
        var array_length = array.length;
        console.log(array_length);
        console.log(array);
        if(array == "" || array == "NULL"){
            lat = -25.344;
            lng = 131.036;
        }
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng(eval(lat), eval(lng)),
          zoom: 4,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        });
        marker = new google.maps.Marker({
                  position: new google.maps.LatLng(eval(lat), eval(lng)),
                  map: map
                });
        var contentString = new Array("");      
        var infowindow = new google.maps.InfoWindow();
        var marker, i;
        var bounds = new google.maps.LatLngBounds();
        for (i = 0; i < array_length; i++) {
                var latitude = array[i]["Latitude"];
                var longitude = array[i]["Longitude"];
                var companyName = array[i]["CompanyName"];
                var number = array[i]["Number"];
                var city = array[i]["CityName"];
                var Streetname = array[i]["Streetname"];
                var Streetname2 = array[i]["Streetname2"];
                var myLatLng = new google.maps.LatLng(latitude,longitude);
                marker = new google.maps.Marker({
                  position: myLatLng,
                  map: map
                });
                bounds.extend(myLatLng);
                contentString[i] = '<div id="content">'+companyName+'</div>'
                google.maps.event.addListener(marker, 'click', (function(marker, i) {
                  return function() {
                    infowindow.setContent(contentString[i]);
                    infowindow.open(map, marker);
                  }
                })(marker, i));
                map.fitBounds(bounds);
        }
      }
    </script>
    <!--Load the API from the specified URL
    * The async attribute allows the browser to render the page while the API loads
    * The key parameter will contain your own API key (which is not needed for this tutorial)
    * The callback parameter executes the initMap() function
    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAmLYjKTYOe8NVNKJ42mnFOO2iEoQck_W4">
    </script>
  </body>
</html>