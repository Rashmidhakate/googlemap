<!DOCTYPE html>
<html>
  <head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <style>
       /* Set the size of the div element that contains the map */
      #map {
        height: 400px;  /* The height is 400 pixels */
        width: 100%;  /* The width is the width of the web page */
       }
    </style>
  </head>
  <body>
    <h3>My Google Maps Demo</h3>
    <form method="post" action="#" name="search_form" id="search_form">
      <input type="text" name="search" id="search" placeholder="search address" />
      <input type="submit" name="submit" id="submit" value="search" />
    </form>
    <!--The div element for the map -->
    <div id="map"></div>
    <script>
      $( "#search_form" ).submit(function( event ) {
        var value = $("#search").val();
        event.preventDefault();
        $.ajax({
            url: "getaddress.php",
            type: "post",
            data: { value : value },
            dataType: "json",
            success: function(data) {
              $.each(data["results"], function( key, value ) {
                var latitude = value["geometry"]["location"]["lat"] ;
                var langitude = value["geometry"]["location"]["lng"] ;
                initMap(latitude,langitude);
              });
            }
        });
      });
      $(document).ready(function(){
          var lat = '-25.344';
          var lng = '131.036';
          initMap(lat,lng);
      });
      // Initialize and add the map
      function initMap($lat,$lng) {
        var location = {lat: eval($lat), lng: eval($lng)};
        //console.log(location);
        var map = new google.maps.Map(
        document.getElementById('map'), {zoom: 4, center: location});
        var contentString = '<div id="content">'+
        '<div id="siteNotice">'+
        '</div>'+
        '<h1 id="firstHeading" class="firstHeading">Uluru</h1>'+
        '<div id="bodyContent">'+
        '<p><b>Uluru</b>, also referred to as <b>Ayers Rock</b>, is a large ' +
        'sandstone rock formation in the southern part of the '+
        'Northern Territory, central Australia. It lies 335&#160;km (208&#160;mi) '+
        'south west of the nearest large town, Alice Springs; 450&#160;km '+
        '(280&#160;mi) by road. Kata Tjuta and Uluru are the two major '+
        'features of the Uluru - Kata Tjuta National Park. Uluru is '+
        'sacred to the Pitjantjatjara and Yankunytjatjara, the '+
        'Aboriginal people of the area. It has many springs, waterholes, '+
        'rock caves and ancient paintings. Uluru is listed as a World '+
        'Heritage Site.</p>'+
        '<p>Attribution: Uluru, <a href="https://en.wikipedia.org/w/index.php?title=Uluru&oldid=297882194">'+
        'https://en.wikipedia.org/w/index.php?title=Uluru</a> '+
        '(last visited June 22, 2009).</p>'+
        '</div>'+
        '</div>';

        var infowindow = new google.maps.InfoWindow({
          content: contentString
        });       
        var marker = new google.maps.Marker({position: location, map: map ,title: 'Address'});
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });
      }
    </script>
    <!--Load the API from the specified URL
    * The async attribute allows the browser to render the page while the API loads
    * The key parameter will contain your own API key (which is not needed for this tutorial)
    * The callback parameter executes the initMap() function
    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAmLYjKTYOe8NVNKJ42mnFOO2iEoQck_W4">
    </script>
  </body>
</html>