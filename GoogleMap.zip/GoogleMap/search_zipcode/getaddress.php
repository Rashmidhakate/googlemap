<?php
$address = $_POST["value"];
// $key = "AIzaSyAmLYjKTYOe8NVNKJ42mnFOO2iEoQck_W4";
// $url = "https://maps.googleapis.com/maps/api/geocode/json?address=".urlencode($address)."&key=$key";
// $ch = curl_init();
// curl_setopt($ch, CURLOPT_URL, $url);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);    
// $body = curl_exec($ch);
// echo $body;
// curl_close($ch);  
$url = "http://www.gls.dk/webservices_v2/wsPakkeshop.asmx";
$op = '/GetParcelShopsInZipcode?zipcode='.$address;
$get_url = $url.$op;
$ch = curl_init($get_url);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: text/xml"]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, FALSE); 
$response = curl_exec($ch);
$value = simplexml_load_string($response);
$json = json_encode($value);
//$shops = json_decode($json,TRUE);
//echo $shops["PakkeshopData"];
echo $json;
// print_r($shops["PakkeshopData"]);
// exit;
?>